java -jar "C:\Tools\grammatica-1.4\lib\grammatica-1.4.jar" condition.grammar --csoutput . --csclassname ZPredication --csnamespace Zanetti.Parser
