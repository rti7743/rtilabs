<?php

        echo confirm_mytest_compiled("abc");

