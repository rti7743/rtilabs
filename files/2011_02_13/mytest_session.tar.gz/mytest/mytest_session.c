#include "mytest_session.h"

/*
	セッションキーでイタヅラをされないようにチェックする.
	php 本体と同じ規則でチェックする.
	/a-zA-Z0-9,\-/ が OK
	長さもバッファを突破しないように.
*/
static int checkSessionKey(const char * key)
{
	const char * p;
	for(p = key ; *p ; p ++)
	{
		if (! ( (*p >= 'a' && *p <= 'z')
			 || (*p >= 'A' && *p <= 'Z')
			 || (*p >= '0' && *p <= '9')
			 || *p == ','
			 || *p == '-'
			))
		{
			/* 無効な文字列 */
			return 0;
		}
	}

	if ( (int)(p - key) > MAXPATHLEN - 20 || key[0] == '\0') 
	{   /*
			-20は /tmp/mytest... などの分の目安w 
			うわっ、私のセッション長すぎ!
		*/
		return 0;
	}
	return 1;
}

/**
セッション用のユニークなランダムな文字列 sid を返す.
目的
	1.セッション用のsid (ランダムなユニークな文字列)を emalloc して返す.

注意
	一見単純そうだが、session_regenerate_idの 罠がある。
	ここが呼ばれ時、セッションが有効な場合と無効な場合がある。
	また一見有効だが、実は無効など、、複雑な場合がある。
	つまり、
	動作1.まったくサラ地の状態でセッションを作る場合 (大部分の場合)
	動作2.セッションは有効で利用できるが、新たに作り直す場合
	動作3.セッションは有効とあるが、実は無効なデータ NULL が入っている場合 session_regenerate_id(TRUE)

	サーバに対する connection pool等をしている場合は要注意である。
	詳しくは、 pecl tokyotyrant の session.c とかを見ればいいよ.
定義
	char *ps_create_sid_##x(void **mod_data, int *newlen TSRMLS_DC)
*/
PS_CREATE_SID_FUNC(mytest)
{
	/*
	php本体のphp_session_create_idを呼び出してユニークな SID をつくってもらう。
	自分で作ってもいいんだろうけど、、、
	*/
	char *sid = php_session_create_id(PS(mod_data), NULL TSRMLS_CC);
	if (!sid)
	{
		php_error_docref(NULL TSRMLS_CC, E_ERROR, "PS_CREATE_SID_FUNC(mytest) SIDがつくれないよ!!");
		return NULL;
	}
	return sid;
}


/**
セッション管理が開始されるとき呼ばれる。
目的
	1.セッション用のメモリの確保
		session = emalloc( sizeof( php_mytest_session ) );
		PS_SET_MOD_DATA(session)
			以後 PS_GET_MOD_DATA() で取り出せる.
	2.格納する場所の初期化を行う。 PS(save_path)

注意
	PS_OPEN_FUNCと名前があるが、
	ここでは、sid がまだわからないので、セッションを open できない。
	なお、connection pool等をここで開始する実装もある。
定義
	int ps_open_##x(void **mod_data, const char *save_path, const char *session_name TSRMLS_DC)
*/
PS_OPEN_FUNC(mytest)
{
	/* セッション用のメモリを確保 */
	php_mytest_session * session = (php_mytest_session*)emalloc( sizeof( php_mytest_session ) );
	if (!session)
	{
		PS_SET_MOD_DATA(NULL);
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_OPEN_FUNC(mytest) セッションが取れないよ");
		return FAILURE;
	}
	/* セッションをセーブするパス */
	session->save_path = estrndup( save_path, strlen( save_path ));

	/* サーバタイプの場合ここで接続することもできる. */

	/* セッションデータの記録 */
	PS_SET_MOD_DATA(session);
	return SUCCESS;
}


/**
セッション管理を開放する時に呼ばれる.
目的
	1.セッション用のメモリの開放
		PS_OPEN_FUNC で確保した領域の開放を行う。

注意
		あとででくる PS_DESTORY_FUNC と紛らわしいが、
		Close の目的は、 Openの逆である。
定義
	int ps_close_##x(void **mod_data TSRMLS_DC)
*/
PS_CLOSE_FUNC(mytest)
{
	/* セッション管理データの読み出し. */
	php_mytest_session * session = PS_GET_MOD_DATA();
	if (!session)
	{
		/* closeなので甘めに. */
		return SUCCESS;
	}

	/* PS_OPEN_FUNCで確保したデータを解放. */
	efree(session->save_path);
	efree(session);

	/* データには、何もありませんよ。 */
	session = NULL;
	PS_SET_MOD_DATA(NULL);

	return SUCCESS;
}


/**
セッションに対する読み込み
目的
	1.セッションデータ key が指すデータを、PS_OPEN_FUNC で準備した
		 PS_GET_MOD_DATA() を使って読み込む
	2.読み込んだデータ *val に書きこむ。
	3.読み込んだデータ長さは *vallen に書く.
定義
	int ps_read_##x(void **mod_data, const char *key, char **val, int *vallen TSRMLS_DC)
*/
PS_READ_FUNC(mytest)
{
	/* セッション管理データの読み出し. */
	php_mytest_session * session = PS_GET_MOD_DATA();
	if (!session)
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_READ_FUNC(mytest) セッションが取れないよ");
		return FAILURE;
	}

	/* 引数 key でイタヅラされないように. */
	if ( ! checkSessionKey(key) )
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_READ_FUNC(mytest) key %s は無効な文字列です" , key);
		return FAILURE;
	}

	/* 引数 key が指し示すデータを開く. */
	char filename[MAXPATHLEN];
	snprintf(filename,MAXPATHLEN,"%s/mytest.session.%s.txt",session->save_path , key );
	filename[MAXPATHLEN - 1] = '\0';

	FILE * fp = fopen(filename,"ab+");
	if (!fp)
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_READ_FUNC(mytest) ファイル %s が開けないよ! %s %d" , filename,strerror(errno), errno);
		return FAILURE;
	}
	flock(fp, LOCK_EX);

	//先頭に戻す.
	rewind(fp);

	struct stat sbuf;
	if (fstat(fileno(fp), &sbuf))
	{
		fclose(fp);
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_READ_FUNC(mytest) ファイル %s の fstat が取れないよ" ,filename,strerror(errno), errno);
		return FAILURE;
	}

	/* データの長さが 0 の場合は特殊な処理をする. */
	if (sbuf.st_size == 0)
	{
		flock(fp, LOCK_UN);
		fclose(fp);
		*val = STR_EMPTY_ALLOC();
		*vallen = 0;
		return SUCCESS;
	}
	
	/* データ長分の領域を確保.*/
	char* readbuffer = (char*)emalloc(sbuf.st_size);
	int readsize = fread(readbuffer,1,sbuf.st_size,fp);

	/* もうデータは不要なのでファイルを閉じる. */
	flock(fp, LOCK_UN);
	fclose(fp);
	
	/* 読めたかな？ */
	if (readsize != sbuf.st_size)
	{
		/* 読めんかった。。 */
		efree(readbuffer);
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_READ_FUNC(mytest) ファイル %s からデータが読み取れないよ" , filename);
		return FAILURE;
	}

	/* 読み込んだデータを返す. (readbufferを開放するのは、phpさんの責任!!) */
	*val = readbuffer;
	*vallen = readsize;

	/* やったー!! */
	return SUCCESS;
}


/**
セッションに対する書き込み
目的
	1.セッションデータ key のデータ val を、PS_OPEN_FUNC で準備した
		 PS_GET_MOD_DATA() を使って書きこむ
	2.データ val のデータの長さ vallen になる.
定義
	int ps_write_##x(void **mod_data, const char *key, const char *val, const int vallen TSRMLS_DC)
*/
PS_WRITE_FUNC(mytest)
{
	/* セッション管理データの読み出し. */
	php_mytest_session * session = PS_GET_MOD_DATA();
	if (!session)
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_WRITE_FUNC(mytest) セッションが取れないよ");
		return FAILURE;
	}

	/* 引数 key でイタヅラされないように. */
	if ( ! checkSessionKey(key) )
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_WRITE_FUNC(mytest) key %s は無効な文字列です" , key);
		return FAILURE;
	}

	/* 引数 key が指し示すデータを開く. */
	char filename[MAXPATHLEN];
	snprintf(filename,MAXPATHLEN,"%s/mytest.session.%s.txt",session->save_path , key );
	filename[MAXPATHLEN - 1] = '\0';

	FILE * fp = fopen(filename,"wb+");
	if (!fp)
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_WRITE_FUNC(mytest) ファイル %s が開けないよ! %s %d" , filename,strerror(errno), errno);
		return FAILURE;
	}
	flock(fp, LOCK_EX);

	/* データ長分の領域を確保. */
	int writesize = fwrite(val,1,vallen,fp);

	/* もうデータは不要なのでファイルを閉じる. */
	flock(fp, LOCK_UN);
	fclose(fp);
	
	/* かけたかな？ */
	if (writesize != vallen)
	{
		/* かけんかった、、、 */
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_WRITE_FUNC(mytest) ファイル %s にかけんかったよ!" , filename);
		return FAILURE;
	}

	return SUCCESS;
}

/**
セッションデータを削除する
目的
	1.セッションデータ key のデータを削除する
注意
	PS_CLOSE_FUNCとは違い、PS_SET_MOD_DATA(NULL)する「わけではない」。
	あくまでも、 key のデータを消去するだけである。
定義
	int ps_delete_##x(void **mod_data, const char *key TSRMLS_DC)
*/
PS_DESTROY_FUNC(mytest)
{
	/* セッション管理データの読み出し. */
	php_mytest_session * session = PS_GET_MOD_DATA();
	if (!session)
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_DESTROY_FUNC(mytest) セッションが取れないよ");
		return FAILURE;
	}

	/* 引数 key でイタヅラされないように. */
	if ( ! checkSessionKey(key) )
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_DESTROY_FUNC(mytest) key %s は無効な文字列です" , key);
		return FAILURE;
	}

	/* 引数 key が指し示すデータを開く. */
	char filename[MAXPATHLEN];
	snprintf(filename,MAXPATHLEN,"%s/mytest.session.%s.txt",session->save_path , key );
	filename[MAXPATHLEN - 1] = '\0';

	/* データ key のデータが入っているファイルを削除する. */
	unlink(filename);

	return SUCCESS;
}


/*
ガページコレクションを行う。
目的
	1.古いデータファイルを削除する
	2.古いデータの定義は、引数 maxlifetime (秒)を過ぎたデータである。
注意
	PHPのセッションは、特定のユーザセッションを利用して、セッションの GC を起動する。
	重いGCを動かすとユーザ体験の阻害になる可能性がある。
	GC が発動する確率は、 PS(gc_probability) / PS(gc_divisor) である。
定義
	int ps_gc_##x(void **mod_data, int maxlifetime, int *nrdels TSRMLS_DC)
*/
PS_GC_FUNC(mytest)
{
	/* セッション管理データの読み出し. 
	save_path を取り出すためだけに利用する... */
	php_mytest_session * session = PS_GET_MOD_DATA();
	if (!session)
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_GC_FUNC(mytest) セッションが取れないよ");
		return FAILURE;
	}
	
	/* GCするためにディレクトリを開く。
	ここにある古いファイルを削除していく. */
	DIR *dir = opendir(session->save_path);
	if (!dir)
	{
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "PS_GC_FUNC(mytest) ディレクトリ %s が開けないよ! %s %d" , session->save_path,strerror(errno), errno);
		return FAILURE;
	}

	/* 現在時刻。
	この時刻をベースに、 引数 maxlifetime (秒) 過ぎているデータを削除していく. */
	time_t now = time(NULL);
	char filename[MAXPATHLEN];

	struct dirent *dire;
	while ((dire = readdir(dir)) != NULL )
	{
		/* セッションデータ以外は無視する. */
		if ( strcmp(dire->d_name , "mytest.session.") != 0)
		{
			continue;
		}

		/* ファイル名の生成 */
		snprintf(filename,MAXPATHLEN,"%s/mytest.session.%s.txt",session->save_path , dire->d_name );
		filename[MAXPATHLEN - 1] = '\0';

		struct stat sbuf;
		if (stat(filename , &sbuf))
		{
			/* 何故か日付とかが読めない... */
			continue;
		}
		
		/* 古いデータ？ */
		if ((now - sbuf.st_mtime) <= maxlifetime)
		{
			/* 古くない. */
			continue;
		}

		/* データを消去する. */

		unlink(filename);
	}

	return SUCCESS;
}



/*
  session_handler を実現するためのおまじない. 
  これは、マクロ展開されて、 PS_CREATE_SID_FUNC などで定義した関数へのルックアップテーブルになるよ。
定義
	typedef struct ps_module_struct {
		const char *s_name;
		int (*s_open)(PS_OPEN_ARGS);
		int (*s_close)(PS_CLOSE_ARGS);
		int (*s_read)(PS_READ_ARGS);
		int (*s_write)(PS_WRITE_ARGS);
		int (*s_destroy)(PS_DESTROY_ARGS);
		int (*s_gc)(PS_GC_ARGS);
		char *(*s_create_sid)(PS_CREATE_SID_ARGS);
	} ps_module;
*/
ps_module ps_mod_mytest = {
  PS_MOD(mytest)
};

