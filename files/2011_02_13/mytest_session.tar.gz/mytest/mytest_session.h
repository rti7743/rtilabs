#ifndef MYTEST_SESSION_H
#define MYTEST_SESSION_H

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_mytest.h"
#include <fcntl.h>



/* セッション管理用のデータ構造 */
typedef struct  {
	char * filename;
	char * save_path;
} php_mytest_session;

#endif //MYTEST_SESSION_H

