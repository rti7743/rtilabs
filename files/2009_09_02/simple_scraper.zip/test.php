<?
	//このソースはサンプルなので、
	//ソースで echo なんてサンプルソースしかできない技をダーティな技をたくさん利用していますwww

	//ライブラリのロード
	require_once('simple_scraper.inc');

	//構築
	$ss = new SimpleScraper();
	//読み込み 文字コードは自動推測してUTF-8に変換してくれます。
	$ret = $ss->LoadURL("http://www.yahoo.co.jp/");
	if (!$ret)
	{
		echo "パースできませんでした。";
		exit;
	}

	//textだけよこせ
	echo "<h2>textだけよこせ</h2>";		
	$nodes = $ss->XPathText("//table");
	foreach($nodes as $n)
	{
		echo htmlspecialchars($n,ENT_QUOTES) . "<br /><br />";
	}

	//innerHTMLでよこせ
	echo "<h2>innerHTMLでよこせ</h2>";
	$nodes = $ss->XPathInnerHTML("//table");
	foreach($nodes as $n)
	{
		echo htmlspecialchars($n,ENT_QUOTES) . "<br /><br />";
	}

	//OuterHTMLでよこせ
	echo "<h2>OuterHTMLでよこせ</h2>";
	$nodes = $ss->XPathOuterHTML("//table");
	foreach($nodes as $n)
	{
		echo htmlspecialchars($n,ENT_QUOTES) . "<br /><br />";
	}

	//meta の Description値
	echo "<h2>meta の description値</h2>";
	$r = $ss->XPathText("//meta[@name='description']/@content");
	echo $r[0];
?>